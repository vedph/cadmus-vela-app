/*
 * Public API Surface of cadmus-part-graffiti-figurative
 */

export * from './lib/grf-figurative-part';
export * from './lib/grf-figurative-part/grf-figurative-part.component';
export * from './lib/grf-figurative-part-feature/grf-figurative-part-feature.component';

export * from './lib/cadmus-part-graffiti-figurative.module';
